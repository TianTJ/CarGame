require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"Car":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'fa1367t7gZGGLtcDl6sc+51', 'Car');
// scripts\Car.js

cc.Class({
    "extends": cc.Component,

    properties: {
        isleft: false,
        type: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.anim = this.getComponent(cc.Animation);
        this.isplaying = false;
    },
    turnDir: function turnDir() {
        if (!this.isplaying) {
            this.isplaying = true;
            if (this.isleft) {
                this.isleft = false;
                if (this.type == 0) {
                    this.anim.play("blueright");
                } else {
                    this.anim.play("yellowright");
                }
            } else {
                this.isleft = true;
                if (this.type == 0) {
                    this.anim.play("blueleft");
                } else {
                    this.anim.play("yellowleft");
                }
            }
        }
    },
    actionEnd: function actionEnd() {
        this.isplaying = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"Game":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'bd9f6HdRa5PKq2iEHt+fP8d', 'Game');
// scripts\Game.js

var Car = require("Car");

cc.Class({
    'extends': cc.Component,

    properties: {
        bluecar: {
            'default': null,
            type: Car
        },
        //分数label
        score: {
            'default': null,
            type: cc.Label
        },
        yellowcar: {
            'default': null,
            type: Car
        },
        bluestar: {
            'default': null,
            type: cc.Prefab
        },
        yellowstar: {
            'default': null,
            type: cc.Prefab
        },
        blueobj: {
            'default': null,
            type: cc.Prefab
        },
        yellowobj: {
            'default': null,
            type: cc.Prefab
        },
        objlayer: {
            'default': null,
            type: cc.Node
        },
        createtime: 1.6 //创建间隔
    },

    // use this for initialization
    onLoad: function onLoad() {

        this.fenshu = 0;
        this.size = cc.director.getWinSize();

        this.setInputControl();

        //this.schedule(this.spawnStar,1);
        //产生左边星星或道具
        this.schedule(this.spawnBuleStar, this.createtime);
        //产生右边星星或道具
        this.schedule(this.spawnYellowStar, this.createtime);
    },
    gainScore: function gainScore() {
        this.fenshu += 1;
        //更新分数
        this.score.string = this.fenshu.toString();
    },
    setInputControl: function setInputControl() {
        var self = this;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: self._onTouchBegan.bind(self)
        }, self);
    },
    _onTouchBegan: function _onTouchBegan(touch, event) {
        //cc.log("%f %f",touch.getLocation().x,touch.getLocation().y);
        if (touch.getLocation().x < this.size.width / 2) {
            this.bluecar.turnDir();
        } else {
            this.yellowcar.turnDir();
        }
        return true;
    },
    spawnBuleStar: function spawnBuleStar() {
        // 使用给定的模板在场景中生成一个新节点
        var type = parseInt(cc.random0To1() * 2);
        if (type == 0) {
            var newStar = cc.instantiate(this.bluestar);
            newStar.getComponent('Star').car = this.bluecar;
            this.objlayer.addChild(newStar);
            newStar.setPosition(this.getNewStarPosition(0));
        } else {
            var newObj = cc.instantiate(this.blueobj);
            newObj.getComponent('Obj').car = this.bluecar;
            this.objlayer.addChild(newObj);
            newObj.setPosition(this.getNewStarPosition(0));
        }
    },
    spawnYellowStar: function spawnYellowStar() {
        var type = parseInt(cc.random0To1() * 2);
        if (type == 0) {
            var newStar = cc.instantiate(this.yellowstar);
            newStar.getComponent('Star').car = this.yellowcar;
            this.objlayer.addChild(newStar);
            newStar.setPosition(this.getNewStarPosition(1));
        } else {
            var newObj = cc.instantiate(this.yellowobj);
            newObj.getComponent('Obj').car = this.yellowcar;
            this.objlayer.addChild(newObj);
            newObj.setPosition(this.getNewStarPosition(1));
        }
    },
    getNewStarPosition: function getNewStarPosition(type) {
        var randX;
        var randY;
        if (type == 0) {
            //随机左边还是右边
            var randdir = parseInt(cc.random0To1() * 2);
            if (randdir == 0) {
                randX = -186;
                //随机y位置
            } else {
                    randX = -63;
                    //随机y位置
                }
        } else if (type == 1) {
                var randdir = parseInt(cc.random0To1() * 2);
                if (randdir == 0) {
                    randX = 63;
                    //随机y位置
                } else {
                        randX = 183;
                        //随机y位置
                    }
            }
        randY = parseInt(cc.random0To1() * 50) + 532;

        // 返回星星坐标
        return cc.p(randX, randY);
    }
});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{"Car":"Car"}],"Obj":[function(require,module,exports){
"use strict";
cc._RFpush(module, '248baLHDMNG3LUuQ5gpiAzZ', 'Obj');
// scripts\Obj.js

cc.Class({
    'extends': cc.Component,

    properties: {
        speed: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.size = cc.director.getWinSize();
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.node.y += this.speed * dt;
        if (this.node.y <= -this.size.height / 2 - 40) {
            this.node.removeFromParent();
            this.node.destroy();
        }
        if (this.car != null && this.detectCollision()) {
            cc.director.loadScene('Game');
        }
    },
    detectCollision: function detectCollision() {
        //矩形碰撞
        var x1 = this.node.x - this.node.width / 2;
        var y1 = this.node.y - this.node.height / 2;
        var w1 = this.node.width;
        var h1 = this.node.height;
        var x2 = this.car.node.x - this.car.node.width / 2 + 40;
        var y2 = this.car.node.y - this.car.node.height / 2 + 40;
        var w2 = this.car.node.width - 80;
        var h2 = this.car.node.height - 80;

        if (x1 >= x2 && x1 >= x2 + w2) {
            return false;
        } else if (x1 <= x2 && x1 + w1 <= x2) {
            return false;
        } else if (y1 >= y2 && y1 >= y2 + h2) {
            return false;
        } else if (y1 <= y2 && y1 + h1 <= y2) {
            return false;
        }
        return true;
    }
});

cc._RFpop();
},{}],"Scroller":[function(require,module,exports){
"use strict";
cc._RFpush(module, '1a7e5z9PdJAEaO5V/Mr5q3Z', 'Scroller');
// scripts\Scroller.js

cc.Class({
    //-- 继承
    "extends": cc.Component,
    //-- 属性
    properties: {
        //-- 滚动的速度
        speed: 0,
        //-- X轴边缘
        resetY: 0
    },

    init: function init(speedMod) {
        this.speed *= speedMod;
    },
    //-- 更新
    update: function update(dt) {
        this.node.y += this.speed * dt;
        if (this.node.y <= this.resetY) {
            this.node.y -= this.resetY;
        }
    }
});

cc._RFpop();
},{}],"Star":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e39e8RvGV9O/LnBrthX1/WL', 'Star');
// scripts\Star.js

cc.Class({
    "extends": cc.Component,

    properties: {
        speed: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.size = cc.director.getWinSize();
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.node.y += this.speed * dt;
        if (this.node.y <= -this.size.height / 2 - 40 && !this.getfen) {
            this.node.removeFromParent();
            this.node.destroy();
        }
        if (this.car != null && this.detectCollision()) {
            this.node.removeFromParent();
            this.node.destroy();
        }
    },
    detectCollision: function detectCollision() {
        //矩形碰撞
        var x1 = this.node.x - this.node.width / 2;
        var y1 = this.node.y - this.node.height / 2;
        var w1 = this.node.width;
        var h1 = this.node.height;
        var x2 = this.car.node.x - this.car.node.width / 2;
        var y2 = this.car.node.y - this.car.node.height / 2;
        var w2 = this.car.node.width;
        var h2 = this.car.node.height;

        if (x1 >= x2 && x1 >= x2 + w2) {
            return false;
        } else if (x1 <= x2 && x1 + w1 <= x2) {
            return false;
        } else if (y1 >= y2 && y1 >= y2 + h2) {
            return false;
        } else if (y1 <= y2 && y1 + h1 <= y2) {
            return false;
        }
        return true;
    }
});

cc._RFpop();
},{}]},{},["Scroller","Obj","Game","Star","Car"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkU6L0NvY29zQ3JlYXRvci9yZXNvdXJjZXMvYXBwLmFzYXIvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsImFzc2V0cy9zY3JpcHRzL0Nhci5qcyIsImFzc2V0cy9zY3JpcHRzL0dhbWUuanMiLCJhc3NldHMvc2NyaXB0cy9PYmouanMiLCJhc3NldHMvc2NyaXB0cy9TY3JvbGxlci5qcyIsImFzc2V0cy9zY3JpcHRzL1N0YXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2ZhMTM2N3Q3Z1pHR0x0Y0RsNnNjKzUxJywgJ0NhcicpO1xuLy8gc2NyaXB0c1xcQ2FyLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBpc2xlZnQ6IGZhbHNlLFxuICAgICAgICB0eXBlOiAwXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmFuaW0gPSB0aGlzLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuICAgICAgICB0aGlzLmlzcGxheWluZyA9IGZhbHNlO1xuICAgIH0sXG4gICAgdHVybkRpcjogZnVuY3Rpb24gdHVybkRpcigpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzcGxheWluZykge1xuICAgICAgICAgICAgdGhpcy5pc3BsYXlpbmcgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHRoaXMuaXNsZWZ0KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc2xlZnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50eXBlID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbmltLnBsYXkoXCJibHVlcmlnaHRcIik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbmltLnBsYXkoXCJ5ZWxsb3dyaWdodFwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuaXNsZWZ0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50eXBlID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbmltLnBsYXkoXCJibHVlbGVmdFwiKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFuaW0ucGxheShcInllbGxvd2xlZnRcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBhY3Rpb25FbmQ6IGZ1bmN0aW9uIGFjdGlvbkVuZCgpIHtcbiAgICAgICAgdGhpcy5pc3BsYXlpbmcgPSBmYWxzZTtcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYmQ5ZjZIZFJhNVBLcTJpRUh0K2ZQOGQnLCAnR2FtZScpO1xuLy8gc2NyaXB0c1xcR2FtZS5qc1xuXG52YXIgQ2FyID0gcmVxdWlyZShcIkNhclwiKTtcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBibHVlY2FyOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBDYXJcbiAgICAgICAgfSxcbiAgICAgICAgLy/liIbmlbBsYWJlbFxuICAgICAgICBzY29yZToge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWxcbiAgICAgICAgfSxcbiAgICAgICAgeWVsbG93Y2FyOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBDYXJcbiAgICAgICAgfSxcbiAgICAgICAgYmx1ZXN0YXI6IHtcbiAgICAgICAgICAgICdkZWZhdWx0JzogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYlxuICAgICAgICB9LFxuICAgICAgICB5ZWxsb3dzdGFyOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWJcbiAgICAgICAgfSxcbiAgICAgICAgYmx1ZW9iajoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXG4gICAgICAgIH0sXG4gICAgICAgIHllbGxvd29iajoge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXG4gICAgICAgIH0sXG4gICAgICAgIG9iamxheWVyOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIGNyZWF0ZXRpbWU6IDEuNiAvL+WIm+W7uumXtOmalFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcblxuICAgICAgICB0aGlzLmZlbnNodSA9IDA7XG4gICAgICAgIHRoaXMuc2l6ZSA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKTtcblxuICAgICAgICB0aGlzLnNldElucHV0Q29udHJvbCgpO1xuXG4gICAgICAgIC8vdGhpcy5zY2hlZHVsZSh0aGlzLnNwYXduU3RhciwxKTtcbiAgICAgICAgLy/kuqfnlJ/lt6bovrnmmJ/mmJ/miJbpgZPlhbdcbiAgICAgICAgdGhpcy5zY2hlZHVsZSh0aGlzLnNwYXduQnVsZVN0YXIsIHRoaXMuY3JlYXRldGltZSk7XG4gICAgICAgIC8v5Lqn55Sf5Y+z6L655pif5pif5oiW6YGT5YW3XG4gICAgICAgIHRoaXMuc2NoZWR1bGUodGhpcy5zcGF3blllbGxvd1N0YXIsIHRoaXMuY3JlYXRldGltZSk7XG4gICAgfSxcbiAgICBnYWluU2NvcmU6IGZ1bmN0aW9uIGdhaW5TY29yZSgpIHtcbiAgICAgICAgdGhpcy5mZW5zaHUgKz0gMTtcbiAgICAgICAgLy/mm7TmlrDliIbmlbBcbiAgICAgICAgdGhpcy5zY29yZS5zdHJpbmcgPSB0aGlzLmZlbnNodS50b1N0cmluZygpO1xuICAgIH0sXG4gICAgc2V0SW5wdXRDb250cm9sOiBmdW5jdGlvbiBzZXRJbnB1dENvbnRyb2woKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICBjYy5ldmVudE1hbmFnZXIuYWRkTGlzdGVuZXIoe1xuICAgICAgICAgICAgZXZlbnQ6IGNjLkV2ZW50TGlzdGVuZXIuVE9VQ0hfT05FX0JZX09ORSxcbiAgICAgICAgICAgIG9uVG91Y2hCZWdhbjogc2VsZi5fb25Ub3VjaEJlZ2FuLmJpbmQoc2VsZilcbiAgICAgICAgfSwgc2VsZik7XG4gICAgfSxcbiAgICBfb25Ub3VjaEJlZ2FuOiBmdW5jdGlvbiBfb25Ub3VjaEJlZ2FuKHRvdWNoLCBldmVudCkge1xuICAgICAgICAvL2NjLmxvZyhcIiVmICVmXCIsdG91Y2guZ2V0TG9jYXRpb24oKS54LHRvdWNoLmdldExvY2F0aW9uKCkueSk7XG4gICAgICAgIGlmICh0b3VjaC5nZXRMb2NhdGlvbigpLnggPCB0aGlzLnNpemUud2lkdGggLyAyKSB7XG4gICAgICAgICAgICB0aGlzLmJsdWVjYXIudHVybkRpcigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy55ZWxsb3djYXIudHVybkRpcigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG4gICAgc3Bhd25CdWxlU3RhcjogZnVuY3Rpb24gc3Bhd25CdWxlU3RhcigpIHtcbiAgICAgICAgLy8g5L2/55So57uZ5a6a55qE5qih5p2/5Zyo5Zy65pmv5Lit55Sf5oiQ5LiA5Liq5paw6IqC54K5XG4gICAgICAgIHZhciB0eXBlID0gcGFyc2VJbnQoY2MucmFuZG9tMFRvMSgpICogMik7XG4gICAgICAgIGlmICh0eXBlID09IDApIHtcbiAgICAgICAgICAgIHZhciBuZXdTdGFyID0gY2MuaW5zdGFudGlhdGUodGhpcy5ibHVlc3Rhcik7XG4gICAgICAgICAgICBuZXdTdGFyLmdldENvbXBvbmVudCgnU3RhcicpLmNhciA9IHRoaXMuYmx1ZWNhcjtcbiAgICAgICAgICAgIHRoaXMub2JqbGF5ZXIuYWRkQ2hpbGQobmV3U3Rhcik7XG4gICAgICAgICAgICBuZXdTdGFyLnNldFBvc2l0aW9uKHRoaXMuZ2V0TmV3U3RhclBvc2l0aW9uKDApKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBuZXdPYmogPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJsdWVvYmopO1xuICAgICAgICAgICAgbmV3T2JqLmdldENvbXBvbmVudCgnT2JqJykuY2FyID0gdGhpcy5ibHVlY2FyO1xuICAgICAgICAgICAgdGhpcy5vYmpsYXllci5hZGRDaGlsZChuZXdPYmopO1xuICAgICAgICAgICAgbmV3T2JqLnNldFBvc2l0aW9uKHRoaXMuZ2V0TmV3U3RhclBvc2l0aW9uKDApKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgc3Bhd25ZZWxsb3dTdGFyOiBmdW5jdGlvbiBzcGF3blllbGxvd1N0YXIoKSB7XG4gICAgICAgIHZhciB0eXBlID0gcGFyc2VJbnQoY2MucmFuZG9tMFRvMSgpICogMik7XG4gICAgICAgIGlmICh0eXBlID09IDApIHtcbiAgICAgICAgICAgIHZhciBuZXdTdGFyID0gY2MuaW5zdGFudGlhdGUodGhpcy55ZWxsb3dzdGFyKTtcbiAgICAgICAgICAgIG5ld1N0YXIuZ2V0Q29tcG9uZW50KCdTdGFyJykuY2FyID0gdGhpcy55ZWxsb3djYXI7XG4gICAgICAgICAgICB0aGlzLm9iamxheWVyLmFkZENoaWxkKG5ld1N0YXIpO1xuICAgICAgICAgICAgbmV3U3Rhci5zZXRQb3NpdGlvbih0aGlzLmdldE5ld1N0YXJQb3NpdGlvbigxKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YXIgbmV3T2JqID0gY2MuaW5zdGFudGlhdGUodGhpcy55ZWxsb3dvYmopO1xuICAgICAgICAgICAgbmV3T2JqLmdldENvbXBvbmVudCgnT2JqJykuY2FyID0gdGhpcy55ZWxsb3djYXI7XG4gICAgICAgICAgICB0aGlzLm9iamxheWVyLmFkZENoaWxkKG5ld09iaik7XG4gICAgICAgICAgICBuZXdPYmouc2V0UG9zaXRpb24odGhpcy5nZXROZXdTdGFyUG9zaXRpb24oMSkpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBnZXROZXdTdGFyUG9zaXRpb246IGZ1bmN0aW9uIGdldE5ld1N0YXJQb3NpdGlvbih0eXBlKSB7XG4gICAgICAgIHZhciByYW5kWDtcbiAgICAgICAgdmFyIHJhbmRZO1xuICAgICAgICBpZiAodHlwZSA9PSAwKSB7XG4gICAgICAgICAgICAvL+maj+acuuW3pui+uei/mOaYr+WPs+i+uVxuICAgICAgICAgICAgdmFyIHJhbmRkaXIgPSBwYXJzZUludChjYy5yYW5kb20wVG8xKCkgKiAyKTtcbiAgICAgICAgICAgIGlmIChyYW5kZGlyID09IDApIHtcbiAgICAgICAgICAgICAgICByYW5kWCA9IC0xODY7XG4gICAgICAgICAgICAgICAgLy/pmo/mnLp55L2N572uXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByYW5kWCA9IC02MztcbiAgICAgICAgICAgICAgICAgICAgLy/pmo/mnLp55L2N572uXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT0gMSkge1xuICAgICAgICAgICAgICAgIHZhciByYW5kZGlyID0gcGFyc2VJbnQoY2MucmFuZG9tMFRvMSgpICogMik7XG4gICAgICAgICAgICAgICAgaWYgKHJhbmRkaXIgPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICByYW5kWCA9IDYzO1xuICAgICAgICAgICAgICAgICAgICAvL+maj+acunnkvY3nva5cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmFuZFggPSAxODM7XG4gICAgICAgICAgICAgICAgICAgICAgICAvL+maj+acunnkvY3nva5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICByYW5kWSA9IHBhcnNlSW50KGNjLnJhbmRvbTBUbzEoKSAqIDUwKSArIDUzMjtcblxuICAgICAgICAvLyDov5Tlm57mmJ/mmJ/lnZDmoIdcbiAgICAgICAgcmV0dXJuIGNjLnAocmFuZFgsIHJhbmRZKTtcbiAgICB9XG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMjQ4YmFMSERNTkczTFV1UTVncGlBelonLCAnT2JqJyk7XG4vLyBzY3JpcHRzXFxPYmouanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBzcGVlZDogMFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5zaXplID0gY2MuZGlyZWN0b3IuZ2V0V2luU2l6ZSgpO1xuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIHVwZGF0ZTogZnVuY3Rpb24gdXBkYXRlKGR0KSB7XG4gICAgICAgIHRoaXMubm9kZS55ICs9IHRoaXMuc3BlZWQgKiBkdDtcbiAgICAgICAgaWYgKHRoaXMubm9kZS55IDw9IC10aGlzLnNpemUuaGVpZ2h0IC8gMiAtIDQwKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgICAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5jYXIgIT0gbnVsbCAmJiB0aGlzLmRldGVjdENvbGxpc2lvbigpKSB7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ0dhbWUnKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZGV0ZWN0Q29sbGlzaW9uOiBmdW5jdGlvbiBkZXRlY3RDb2xsaXNpb24oKSB7XG4gICAgICAgIC8v55+p5b2i56Kw5pKeXG4gICAgICAgIHZhciB4MSA9IHRoaXMubm9kZS54IC0gdGhpcy5ub2RlLndpZHRoIC8gMjtcbiAgICAgICAgdmFyIHkxID0gdGhpcy5ub2RlLnkgLSB0aGlzLm5vZGUuaGVpZ2h0IC8gMjtcbiAgICAgICAgdmFyIHcxID0gdGhpcy5ub2RlLndpZHRoO1xuICAgICAgICB2YXIgaDEgPSB0aGlzLm5vZGUuaGVpZ2h0O1xuICAgICAgICB2YXIgeDIgPSB0aGlzLmNhci5ub2RlLnggLSB0aGlzLmNhci5ub2RlLndpZHRoIC8gMiArIDQwO1xuICAgICAgICB2YXIgeTIgPSB0aGlzLmNhci5ub2RlLnkgLSB0aGlzLmNhci5ub2RlLmhlaWdodCAvIDIgKyA0MDtcbiAgICAgICAgdmFyIHcyID0gdGhpcy5jYXIubm9kZS53aWR0aCAtIDgwO1xuICAgICAgICB2YXIgaDIgPSB0aGlzLmNhci5ub2RlLmhlaWdodCAtIDgwO1xuXG4gICAgICAgIGlmICh4MSA+PSB4MiAmJiB4MSA+PSB4MiArIHcyKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0gZWxzZSBpZiAoeDEgPD0geDIgJiYgeDEgKyB3MSA8PSB4Mikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGVsc2UgaWYgKHkxID49IHkyICYmIHkxID49IHkyICsgaDIpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSBlbHNlIGlmICh5MSA8PSB5MiAmJiB5MSArIGgxIDw9IHkyKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICcxYTdlNXo5UGRKQUVhTzVWL01yNXEzWicsICdTY3JvbGxlcicpO1xuLy8gc2NyaXB0c1xcU2Nyb2xsZXIuanNcblxuY2MuQ2xhc3Moe1xuICAgIC8vLS0g57un5om/XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcbiAgICAvLy0tIOWxnuaAp1xuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8tLSDmu5rliqjnmoTpgJ/luqZcbiAgICAgICAgc3BlZWQ6IDAsXG4gICAgICAgIC8vLS0gWOi9tOi+uee8mFxuICAgICAgICByZXNldFk6IDBcbiAgICB9LFxuXG4gICAgaW5pdDogZnVuY3Rpb24gaW5pdChzcGVlZE1vZCkge1xuICAgICAgICB0aGlzLnNwZWVkICo9IHNwZWVkTW9kO1xuICAgIH0sXG4gICAgLy8tLSDmm7TmlrBcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIHVwZGF0ZShkdCkge1xuICAgICAgICB0aGlzLm5vZGUueSArPSB0aGlzLnNwZWVkICogZHQ7XG4gICAgICAgIGlmICh0aGlzLm5vZGUueSA8PSB0aGlzLnJlc2V0WSkge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnkgLT0gdGhpcy5yZXNldFk7XG4gICAgICAgIH1cbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2UzOWU4UnZHVjlPL0xuQnJ0aFgxL1dMJywgJ1N0YXInKTtcbi8vIHNjcmlwdHNcXFN0YXIuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHNwZWVkOiAwXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLnNpemUgPSBjYy5kaXJlY3Rvci5nZXRXaW5TaXplKCk7XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgdXBkYXRlOiBmdW5jdGlvbiB1cGRhdGUoZHQpIHtcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy5zcGVlZCAqIGR0O1xuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPD0gLXRoaXMuc2l6ZS5oZWlnaHQgLyAyIC0gNDAgJiYgIXRoaXMuZ2V0ZmVuKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgICAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5jYXIgIT0gbnVsbCAmJiB0aGlzLmRldGVjdENvbGxpc2lvbigpKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgICAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZGV0ZWN0Q29sbGlzaW9uOiBmdW5jdGlvbiBkZXRlY3RDb2xsaXNpb24oKSB7XG4gICAgICAgIC8v55+p5b2i56Kw5pKeXG4gICAgICAgIHZhciB4MSA9IHRoaXMubm9kZS54IC0gdGhpcy5ub2RlLndpZHRoIC8gMjtcbiAgICAgICAgdmFyIHkxID0gdGhpcy5ub2RlLnkgLSB0aGlzLm5vZGUuaGVpZ2h0IC8gMjtcbiAgICAgICAgdmFyIHcxID0gdGhpcy5ub2RlLndpZHRoO1xuICAgICAgICB2YXIgaDEgPSB0aGlzLm5vZGUuaGVpZ2h0O1xuICAgICAgICB2YXIgeDIgPSB0aGlzLmNhci5ub2RlLnggLSB0aGlzLmNhci5ub2RlLndpZHRoIC8gMjtcbiAgICAgICAgdmFyIHkyID0gdGhpcy5jYXIubm9kZS55IC0gdGhpcy5jYXIubm9kZS5oZWlnaHQgLyAyO1xuICAgICAgICB2YXIgdzIgPSB0aGlzLmNhci5ub2RlLndpZHRoO1xuICAgICAgICB2YXIgaDIgPSB0aGlzLmNhci5ub2RlLmhlaWdodDtcblxuICAgICAgICBpZiAoeDEgPj0geDIgJiYgeDEgPj0geDIgKyB3Mikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGVsc2UgaWYgKHgxIDw9IHgyICYmIHgxICsgdzEgPD0geDIpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSBlbHNlIGlmICh5MSA+PSB5MiAmJiB5MSA+PSB5MiArIGgyKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0gZWxzZSBpZiAoeTEgPD0geTIgJiYgeTEgKyBoMSA8PSB5Mikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiXX0=
