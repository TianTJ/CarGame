"use strict";
cc._RFpush(module, '1a7e5z9PdJAEaO5V/Mr5q3Z', 'Scroller');
// scripts\Scroller.js

cc.Class({
    //-- 继承
    "extends": cc.Component,
    //-- 属性
    properties: {
        //-- 滚动的速度
        speed: 0,
        //-- X轴边缘
        resetY: 0
    },

    init: function init(speedMod) {
        this.speed *= speedMod;
    },
    //-- 更新
    update: function update(dt) {
        this.node.y += this.speed * dt;
        if (this.node.y <= this.resetY) {
            this.node.y -= this.resetY;
        }
    }
});

cc._RFpop();